@extends('layouts.app')
@section('content')

<div class="container"><h1>Create New Role</h1>

<form method="POST" action="{{route('roles.store')}}">
	@csrf

	<div class="form-group">
		<label for="name"> Role
		</label>
			<input type="text" id="name" name="name" class="form-control" required>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-success">Create</button>
	</div>

</form>
</div>
@endsection