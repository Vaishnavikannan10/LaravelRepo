@extends('layouts.app')
<div class="container">
	<div>
		<form method="post" action="{{route('login')}}">
			@csrf
			<div class="form-group">
				<label for="email"> Email
				</label>
					<input type="email" id=email name="email" class="form-control" required>
			</div>

			<div class="form-group">
				<label for="password"> Password
				</label>
					<input type="password" id=password name="password" class="form-control" required>
			</div>

			<div class="form-group">
				<button type="submit" class="btn btn-primary">Login</button>
			</div>

		</form>
	</div>
</div>