@extends('layouts.app')
@section('content')

<div class="container"><h5>Create Entry</h5>

<form method="POST" action="{{route('entries.store')}}">
	@csrf

	<div class="form-group">
		<label for="item"> Item
		</label>
			<input type="text" id="item" name="item" class="form-control" required>
	</div>

	<div class="form-group">
		<label for="type"> Type
		</label>
			<select class="form-control" id="type" required name="type" selected>
				<option value="income">Income</option>
				<option value="expense">Expense</option>
			</select>
	</div>

	<div class="form-group">
		<label for="amount"> Amount
		</label>
			<input type="text" id="amount" name="amount" class="form-control" required>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-success">Create</button>
	</div>

</form>
</div>
@endsection