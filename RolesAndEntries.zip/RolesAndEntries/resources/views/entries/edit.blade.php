@extends('layouts.app')
@section('content')

<div class="container"><h5>Edit Entry</h5>

<form method="POST" action="{{route('entries.update', $entry->id)}}">
	@csrf
	@method('PUT') 
	<div class="form-group">
		<label for="item"> Item
		</label>
			<input type="text" id="item" name="item" class="form-control" value="{{$entry->item}}"required>
	</div>

	<div class="form-group">
		<label for="type"> Type
		</label>
			<select name="type" id="type" class="form-control" required>
                    <option value="income" {{ $entry->type == 'income' ? 'selected' : '' }}>Income</option>
                    <option value="expense" {{ $entry->type == 'expense' ? 'selected' : '' }}>Expense</option>
                </select>
	</div>

	<div class="form-group">
		<label for="amount"> Amount
		</label>
			<input type="text" id="amount" name="amount" class="form-control" value="{{$entry->amount}}" required>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-success">Update</button>
	</div>

</form>
</div>
@endsection