@extends('layouts.app')
@section('content')
<div class="container">
	<h1>Entries</h1>

	<table id="users-table">
		<thead>
			<tr>
				<th>Id</th>
				<th>Item</th>
				<th>Type</th>
				<th>Amount</th>
				@if (auth()->user()->hasRole('Admin'))
				<th>User</th>
				@endif
				@if (!auth()->user()->hasRole('Admin'))
				<th>Actions</th>
				@endif
			</tr>
		</thead>
		<tbody>
			@foreach($entries as $entry)
			<tr>
				<td>{{$entry->id}}</td>
				<td>{{$entry->item}}</td>
				<td>{{$entry->type}}</td>
				<td>{{$entry->amount}}</td>
				@if (auth()->user()->hasRole('Admin'))
				<td>{{$entry->user->name}}</td>
				@endif
				@if (!auth()->user()->hasRole('Admin'))
				<td><a href="{{route('entries.edit',$entry)}}" class="btn btn-primary">Edit</a><form action="{{route('entries.destroy',$entry)}}" method="POST" onsubmit="return confirm('Are you sure?');">
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-danger">Delete</button>
				</form></td>
				@endif
			</tr>
			@endforeach
		</tbody>
		<tfoot><td colspan="3">Net Amount:</td><td colspan="2">{{number_format($netTotal,2)}}</td>
	</table>
</div>
@endsection