
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('users.store')); ?>">
	<?php echo csrf_field(); ?>
	<div class="form-group">
		<label for="name"> Name
		</label>
			<input type="text" id=name name="name" class="form-control" required>
	</div>
	<div class="form-group">
		<label for="email"> Email
		</label>
			<input type="text" id=email name="email" class="form-control" required>
	</div>

	<div class="form-group">
		<label for="password"> Password
		</label>
			<input type="password" id=password name="password" class="form-control" required>
	</div>

	<div class="form-group">
		<label for="password"> Role
		</label>
		<select name="role" class="form-control">
			<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-primary">Create User</button>
	</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/users/create.blade.php ENDPATH**/ ?>