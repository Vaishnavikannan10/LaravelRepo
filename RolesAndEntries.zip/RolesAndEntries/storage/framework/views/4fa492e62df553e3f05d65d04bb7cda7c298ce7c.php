

<?php $__env->startSection('content'); ?>
<div class="container">
	<h1>Roles</h1>
	<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">Create New Role</a>
<table id="users-table">
	<thead>
		<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Actions</th>
</tr>
</thead>
	<tbody>
		<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($role->id); ?></td>
				<td><?php echo e($role->name); ?></td>
				<td><form action="<?php echo e(route('roles.destroy',$role)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<button type="submit" class="btn btn-danger">Delete</button>
				</form></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/roles/index.blade.php ENDPATH**/ ?>