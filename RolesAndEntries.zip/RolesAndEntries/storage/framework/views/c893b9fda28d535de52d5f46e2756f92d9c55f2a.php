
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Roles And Entries</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#users-table').DataTable();	
		});
	</script>
</head>
<body>
	<?php if(auth()->guard()->check()): ?>
	<div class="container">
		<h4>Logged in as: <?php echo e(auth()->user()->name); ?></h4>
		<h5>Current Role:
			<?php if(auth()->user()->roles->isNotEmpty()): ?>
			<?php echo e(auth()->user()->roles->first()->name); ?>

		    <?php endif; ?>
		</h5>
		<?php if(auth()->user()->hasRole('Admin')): ?>
		<a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Create New User</a>
		<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">Create New Roles</a>
		<?php endif; ?>
		<a href="<?php echo e(route('entries.create')); ?>" class="btn btn-primary">Create New Entries</a>

		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		</form>
		<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit()" class="btn btn-primary">Logout</a>
	</div>
</div>
<?php endif; ?>
	<main>
		<?php echo $__env->yieldContent('content'); ?>
</main>
</body>
</html><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/layouts/app.blade.php ENDPATH**/ ?>