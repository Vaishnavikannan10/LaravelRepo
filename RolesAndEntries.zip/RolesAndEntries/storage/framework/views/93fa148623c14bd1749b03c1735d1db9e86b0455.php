
<?php $__env->startSection('content'); ?>
<div class="container">
	<h1>Entries</h1>

	<table id="users-table">
		<thead>
			<tr>
				<th>Id</th>
				<th>Item</th>
				<th>Type</th>
				<th>Amount</th>
				<?php if(auth()->user()->hasRole('Admin')): ?>
				<th>User</th>
				<?php endif; ?>
				<?php if(!auth()->user()->hasRole('Admin')): ?>
				<th>Actions</th>
				<?php endif; ?>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($entry->id); ?></td>
				<td><?php echo e($entry->item); ?></td>
				<td><?php echo e($entry->type); ?></td>
				<td><?php echo e($entry->amount); ?></td>
				<?php if(auth()->user()->hasRole('Admin')): ?>
				<td><?php echo e($entry->user->name); ?></td>
				<?php endif; ?>
				<?php if(!auth()->user()->hasRole('Admin')): ?>
				<td><a href="<?php echo e(route('entries.edit',$entry)); ?>" class="btn btn-primary">Edit</a><form action="<?php echo e(route('entries.destroy',$entry)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<button type="submit" class="btn btn-danger">Delete</button>
				</form></td>
				<?php endif; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		<tfoot><td colspan="3">Net Amount:</td><td colspan="2"><?php echo e(number_format($netTotal,2)); ?></td>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/entries/index.blade.php ENDPATH**/ ?>