
<div class="container">
	<div>
		<form method="post" action="<?php echo e(route('login')); ?>">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="email"> Email
				</label>
					<input type="email" id=email name="email" class="form-control" required>
			</div>

			<div class="form-group">
				<label for="password"> Password
				</label>
					<input type="password" id=password name="password" class="form-control" required>
			</div>

			<div class="form-group">
				<button type="submit" class="btn btn-primary">Login</button>
			</div>

		</form>
	</div>
</div>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/auth/login.blade.php ENDPATH**/ ?>