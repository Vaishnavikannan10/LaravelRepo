
<?php $__env->startSection('content'); ?>

<div class="container"><h5>Create Entry</h5>

<form method="POST" action="<?php echo e(route('entries.store')); ?>">
	<?php echo csrf_field(); ?>

	<div class="form-group">
		<label for="item"> Item
		</label>
			<input type="text" id="item" name="item" class="form-control" required>
	</div>

	<div class="form-group">
		<label for="type"> Type
		</label>
			<select class="form-control" id="type" required name="type" selected>
				<option value="income">Income</option>
				<option value="expense">Expense</option>
			</select>
	</div>

	<div class="form-group">
		<label for="amount"> Amount
		</label>
			<input type="text" id="amount" name="amount" class="form-control" required>
	</div>

	<div class="form-group">
		<button type="submit" class="btn btn-success">Create</button>
	</div>

</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp81\htdocs\RolesAndEntries\resources\views/entries/create.blade.php ENDPATH**/ ?>