<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Entry;
use Illuminate\Support\Facades\Auth;

class EntryController extends Controller
{
     public function __construct(){
        $this->middleware('auth');
     }

     public function index(){
        $entries = Auth::user()->hasRole('Admin') ? Entry::with('user')->paginate(10) : Entry:: with('user')->where('user_id',auth()->id())->paginate(10);
        $totalIncome = $entries->where('type','income')->sum('amount');
        $totalExpense = $entries->where('type','expense')->sum('amount');
        $netTotal = $totalIncome - $totalExpense;
        return view('entries.index',compact('entries','netTotal'));
    }

    public function create(){
        return view('entries.create');
    }

    public function store(Request $request){
         $request->validate([
            'type' => 'required|in:income,expense',
            'amount' => 'required|numeric',
            'item' => 'nullable|string'
        ]);

         Entry::create([
            'type' => $request->type,
            'amount' =>  $request->amount,
            'item' =>  $request->item,
            'user_id' => auth()->id()
         ]);
         return redirect()->route('entries.index')->with('success','Entry created successfully');
    }

    public function update(Request $request,$id){
         $request->validate([
            'type' => 'required|in:income,expense',
            'amount' => 'required|numeric',
            'item' => 'nullable|string'
        ]);
         $entry = Entry::findorFail($id);
         $entry->update($request->all());
         return redirect()->route('entries.index')->with('success','Entry updated successfully');
    }

    public function edit($id){
        $entry = Entry::findOrFail($id);
        return view('entries.edit', compact('entry'));
    }

    public function destroy($id){
        $entry = Entry::findorFail($id);
        return redirect()->route('entries.index')->with('success','Entry deleted successfully');
    }
}
