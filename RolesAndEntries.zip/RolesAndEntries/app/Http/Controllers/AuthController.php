<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{
    public function showLoginForm(){
        //Check if the user is logged in
        if(Auth::check()){
            if(auth()->user()->hasRole('Admin')){
                //If the user is logged in as admin redirect to users page otherwise redirect to entries
                 return redirect()->intended('/users');
            }else{
                return redirect()->intended('/entries');
            }
        }
        return view('auth.login');
    }

    public function login(Request $request){
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if(Auth::attempt(['email' => $request->email,'password' => $request->password])){
            if(auth()->user()->hasRole('Admin')){
                return redirect()->intended('/users');
            }

            return redirect()->intended('/entries');
            
        }

        return back()->withErrors(['email' => 'Please check credentials']);

    }

    public function logout(Request $request){
        Auth::logout();
        return redirect('/login');
    }
}
